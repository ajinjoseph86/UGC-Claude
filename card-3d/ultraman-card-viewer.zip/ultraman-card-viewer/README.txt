Ultraman card viewer (3D)

Open card-viewer.html in Chrome (double-click, or drag it into a Chrome window).
It is fully self-contained and works offline.

Controls
- Drag: tilt the card (reflections and holo foil move with the angle)
- Scroll / pinch: zoom
- Double-tap or "Flip": turn the card over
- Dropdown: switch between Card 1 (Ultraman Geed) and Card 2 (Ultraman Zero)
- Turn slider: rotate the card to any angle
- Auto-rotate slider: spin speed (far left = off)
- Sway / Foil / Reset: toggle auto-motion, toggle holo foil, reset view

The textures/ folder holds the flattened card images, for reference only.
The viewer does not need them.
